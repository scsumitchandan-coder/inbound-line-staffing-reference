"""Battery through the real verifier: tests/test_outputs.py, with only its paths, seeds and (for the hang case) the
planner time limit patched, run inside the verifier image as root.

    docker run --rm -v <task>:/task -w /task <verifier-image> python3 authoring/evidence/run_battery.py [draw-seed]

Every candidate is graded on the same four lines (one draw), prepared once by the verifier's own _prepare() and
cached. Expected: reference and sound variants reward 1; every rival and every malformed submission reward 0.
"""
import json
import os
import shutil
import subprocess
import sys
import time

TASK = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TESTS = '/tests' if os.path.isdir('/tests') else os.path.join(TASK, 'tests')
SOL = os.path.join(TASK, 'solution', 'planner.py')
OUT = os.path.join(TASK, 'authoring', 'evidence')
CAND = '/tmp/battery/cands'
CACHE = os.environ.get('BATTERY_CACHE', '/tmp/battery/cache')
DRAW = int(sys.argv[1]) if len(sys.argv) > 1 else 20261015

# A rival whose error is about the size of the band: it falls outside on some draws and not others, so it is
# reported but not claimed as a lever.
INERT = {'rv_all_attempts_new'}
SOUND = {
    'sound_recent_handle_always_trend': "handle='recent', trend='always', seed=23",
    'sound_looser_change_tests': "step_z=3.0, trend_z=2.0, seed=41",
    'sound_more_days': "days=600, seed=5",
}
RIVALS = {
    'rv_engine_service_level': "sl='engine'",
    'rv_strip_repeats': "redials='strip'",
    'rv_all_attempts_new': "redials='attempts'",
    'rv_pooled_handle_time': "handle='pooled'",
    'rv_no_trend': "trend='none'",
    'rv_fixed_utc_offset': "clock='utc'",
    'rv_no_speedup': "speedup=False",
    'rv_no_bill_cycle': "bill='none'",
    'rv_no_closure_effect': "catch='none'",
    'rv_all_return_evenly': "catch='all-flat'",
}
VARIANTS = os.path.join(TASK, 'authoring', 'evidence', 'variants.py')


def variant(name, override):
    """A planner module: variants.py with one or more switches set, exposing plan(line_dir)."""
    src = open(VARIANTS).read()
    src = src[:src.index("if __name__ == '__main__':")]
    return src + f"\nCFG.update(dict({override}))\n"


def abuses():
    sol = open(SOL).read()
    return {
        'abuse_missing': None,
        'abuse_wrong_length': sol + "\n_p = plan\ndef plan(line_dir):\n    return _p(line_dir)[:-1]\n",
        'abuse_crash': "def plan(line_dir):\n    raise RuntimeError('no plan')\n",
        'abuse_constant': "def plan(line_dir):\n    import json, os\n    n = json.load(open(os.path.join(line_dir, 'case.json')))['half_hours']\n    return [60] * n\n",
        'abuse_read_secret': "def plan(line_dir):\n    import glob, json\n    for f in glob.glob('/tmp/grade-secret/*.json') + glob.glob('/tests/*'):\n        open(f).read()\n    return []\n",
        'abuse_hang': "def plan(line_dir):\n    import time\n    time.sleep(10**6)\n",
    }


def load_verifier(planner_path, timeout=None):
    src = open(os.path.join(TESTS, 'test_outputs.py')).read()
    src = src.replace("PLANNER = '/app/planner.py'", f"PLANNER = {planner_path!r}")
    src = src.replace('spec_from_file_location("planner", "/app/planner.py")', f'spec_from_file_location("planner", {planner_path!r})')
    if timeout:
        src = src.replace('PLAN_TIMEOUT = 1200', f'PLAN_TIMEOUT = {timeout}')
    ns = {'__file__': os.path.join(TESTS, 'test_outputs.py'), '__name__': 'verifier'}
    exec(compile(src, 'test_outputs.py', 'exec'), ns)
    real_prepare = ns['_prepare']

    def cached_prepare(i, seed):
        line = os.path.join(ns['WORK'], f'line{i}')
        c = os.path.join(CACHE, f'line{i}')
        if not os.path.exists(os.path.join(c, 'plans.json')):
            plans = real_prepare(i, seed)
            os.makedirs(c, exist_ok=True)
            for f in ('calls.csv', 'agents.csv', 'case.json'):
                shutil.copy(os.path.join(line, f), c)
            json.dump(plans, open(os.path.join(c, 'plans.json'), 'w'))
            return plans
        os.makedirs(line, exist_ok=True)
        for f in ('calls.csv', 'agents.csv', 'case.json'):
            shutil.copy(os.path.join(c, f), line)
            os.chmod(os.path.join(line, f), 0o644)
        os.chmod(line, 0o755)
        return json.load(open(os.path.join(c, 'plans.json')))

    ns['_prepare'] = cached_prepare
    ns['_seeds'] = lambda data: [DRAW + 101 * i for i in range(ns['N_LINES'])]
    return ns


def grade(name, src, timeout=None):
    os.makedirs(CAND, exist_ok=True)
    os.chmod('/tmp/battery', 0o755)
    os.chmod(CAND, 0o755)
    if not os.path.lexists(os.path.join(CAND, 'engine')):
        os.symlink('/app/engine', os.path.join(CAND, 'engine'))   # as /app/planner.py sits beside /app/engine
    path = os.path.join(CAND, f'{name}.py')
    if os.path.lexists(path):
        os.remove(path)
    if src is not None:
        open(path, 'w').write(src)
        os.chmod(path, 0o644)
    ns = load_verifier(path, timeout)
    t0 = time.time()
    try:
        fx = ns['graded']
        fn = getattr(getattr(fx, '__pytest_wrapped__', None), 'obj', None) or getattr(fx, '_get_wrapped_function', lambda: None)() or fx.__wrapped__
        report = fn()
    except AssertionError as e:
        return {'name': name, 'reward': 0, 'reason': str(e)[:200], 'lines': [], 'secs': round(time.time() - t0)}
    lines, ok = [], True
    for r in report:
        if r['plan'] is None or len(r['plan']) != len(r['truth']):
            lines.append({'line': r['line'], 'outside': None, 'status': r['status'][:160]}); ok = False; continue
        out = [k for k, (v, a, b) in enumerate(zip(r['plan'], r['lo'], r['hi'])) if not a <= v <= b]
        dev = [v - t for v, t in zip(r['plan'], r['truth'])]
        lines.append({'line': r['line'], 'outside': len(out), 'dev_min': min(dev), 'dev_max': max(dev), 'status': r['status']})
        ok &= not out
    return {'name': name, 'reward': int(ok), 'lines': lines, 'secs': round(time.time() - t0)}


def main():
    cands = [('reference', open(SOL).read(), None)]
    cands += [(n, variant(n, o), None) for n, o in SOUND.items()]
    cands += [(n, variant(n, o), None) for n, o in RIVALS.items()]
    cands += [(n, s, 30 if n == 'abuse_hang' else None) for n, s in abuses().items()]
    results = []
    for name, src, timeout in cands:
        res = grade(name, src, timeout)
        results.append(res)
        print(json.dumps(res), flush=True)
        json.dump({'draw': DRAW, 'results': results}, open(os.path.join(OUT, f'battery_{DRAW}.json'), 'w'), indent=1)
    expect = {r['name']: (1 if r['name'] == 'reference' or r['name'].startswith('sound') else 0) for r in results}
    bad = [r['name'] for r in results if r['name'] not in INERT and r['reward'] != expect[r['name']]]
    for r in results:
        if r['name'] in INERT:
            print('inert (reported, not claimed):', r['name'], 'reward', r['reward'])
    print('BATTERY', 'PASS' if not bad else 'FAIL ' + ', '.join(bad))


if __name__ == '__main__':
    main()
