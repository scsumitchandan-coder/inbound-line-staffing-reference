"""Multi-draw survey: for each draw, build the four role lines exactly as the verifier does, compute the true
requirement and the band, and score sound methods and rivals (outside-band half hours per line).

    docker run --rm -v <task>:/task -w /task <verifier-image> python3 authoring/provenance/survey_draws.py D1 D2 ...

A sound method must have 0 outside everywhere; a rival must be outside somewhere in every draw.
"""
import json
import os
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor

TASK = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TESTS = os.path.join(TASK, 'tests')
sys.path.insert(0, TESTS)
os.environ.setdefault('GENSIM', '/tests/gensim' if os.path.exists('/tests/gensim') else os.path.join(TESTS, 'gensim'))
os.environ.setdefault('QPLAN_DIR', '/app/engine')
import centre  # noqa: E402

BAND = ('reference', 'recent')   # tests/sound.py methods; everything else from authoring/evidence/variants.py
OTHERS = {
    'sound_looser_change_tests': {'step_z': 3.0, 'trend_z': 2.0, 'seed': 41},
    'sound_more_days': {'days': 600, 'seed': 5},
    'rv_engine_service_level': {'sl': 'engine'},
    'rv_strip_repeats': {'redials': 'strip'},
    'rv_all_attempts_new': {'redials': 'attempts'},
    'rv_pooled_handle_time': {'handle': 'pooled'},
    'rv_no_trend': {'trend': 'none'},
    'rv_fixed_utc_offset': {'clock': 'utc'},
    'rv_no_speedup': {'speedup': False},
    'rv_no_bill_cycle': {'bill': 'none'},
    'rv_no_closure_effect': {'catch': 'none'},
    'rv_all_return_evenly': {'catch': 'all-flat'},
}
OUT = os.path.join(TASK, 'authoring', 'evidence', 'survey')


def build(args):
    seed, d, role = args
    res = centre.build(seed, d, truth=True, reps=300, role=role)
    return res['truth']


def run(args):
    d, name, cfg = args
    out = os.path.join(d, f'_{name}.csv')
    if not os.path.exists(out):
        if cfg is None:
            cmd = [sys.executable, os.path.join(TESTS, 'sound.py'), d, out, name]
        else:
            cmd = [sys.executable, os.path.join(TASK, 'authoring', 'evidence', 'variants.py'), d, out, json.dumps(cfg)]
        subprocess.run(cmd, check=True, capture_output=True)
    with open(out) as fh:
        return [int(r.split(',')[1]) for r in fh.read().split()[1:]]


def main():
    draws = [int(x) for x in sys.argv[1:]] or [1]
    jobs = int(os.environ.get('JOBS', '4'))
    os.makedirs(OUT, exist_ok=True)
    allres = {}
    for draw in draws:
        seeds = [draw + 101 * i for i in range(len(centre.ROLES))]
        dirs = [f'/tmp/survey/d{draw}/line{i}' for i in range(len(seeds))]
        names = list(BAND) + list(OTHERS)
        cfgs = {**{b: None for b in BAND}, **OTHERS}
        with ProcessPoolExecutor(jobs) as ex:
            truths = list(ex.map(build, [(s, d, centre.ROLES[i]) for i, (s, d) in enumerate(zip(seeds, dirs))]))
            tasks = [(d, n, cfgs[n]) for d in dirs for n in names]
            plans = dict(zip([(d, n) for d, n, _ in tasks], ex.map(run, tasks)))
        res = {}
        for i, d in enumerate(dirs):
            stack = list(zip(truths[i], *[plans[(d, b)] for b in BAND]))
            lo = [min(c) - 1 for c in stack]
            hi = [max(c) + 1 for c in stack]
            for n in names:
                p = plans[(d, n)]
                res.setdefault(n, []).append(sum(not (a <= v <= b) for v, a, b in zip(p, lo, hi)))
        allres[draw] = res
        print('draw', draw, json.dumps(res), flush=True)
        json.dump(allres, open(os.path.join(OUT, 'survey_draws.json'), 'w'), indent=1)
    names = list(BAND) + list(OTHERS)
    print('SUMMARY over %d draws' % len(draws))
    for n in names:
        fails = sum(1 for r in allres.values() if sum(r[n]) > 0)
        print('  %-28s draws with any half hour outside: %d/%d' % (n, fails, len(draws)))


if __name__ == '__main__':
    main()
