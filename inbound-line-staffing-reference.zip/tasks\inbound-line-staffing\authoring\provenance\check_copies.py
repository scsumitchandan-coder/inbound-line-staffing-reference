"""Confirm the byte-identical copies the task relies on.

- the practice line's generator (environment/_build) and the verifier's generator (tests/) are the same code;
- the queue engine the agent gets (environment/app/engine) and the one the verifier installs at /app/engine
  (tests/engine) are the same files;
- the reference planner (solution/planner.py) and the verifier's sound methods (tests/sound.py) share every
  estimating and staffing function, and the reference's embedded simulator SIM_C is tests/gensim.c byte for byte.
"""
import hashlib
import pathlib
import sys

TASK = pathlib.Path(__file__).resolve().parents[2]
PAIRS = [('environment/_build/centre.py', 'tests/centre.py'), ('environment/_build/gensim.c', 'tests/gensim.c')]
PAIRS += [(f'environment/app/engine/{f}', f'tests/engine/{f}') for f in ('qplan.c', 'qplan.py', 'ENGINE.md', 'checks.csv')]
bad = 0
for a, b in PAIRS:
    ha = hashlib.sha256((TASK / a).read_bytes()).hexdigest()
    hb = hashlib.sha256((TASK / b).read_bytes()).hexdigest()
    print(('same ' if ha == hb else 'DIFF ') + ha[:16], a, b)
    bad += ha != hb


def functions(p):
    import ast
    src = (TASK / p).read_text()
    tree = ast.parse(src)
    return {n.name: ast.get_source_segment(src, n) for n in tree.body if isinstance(n, ast.FunctionDef)}, src


SHARED = ('load', 'localise', 'linked_redials', 'estimate', 'staff', 'change_point_weeks', 'plan')
fs, ssrc = functions('solution/planner.py')
ft, _ = functions('tests/sound.py')
for name in SHARED:
    same = fs.get(name) == ft.get(name)
    print(('same ' if same else 'DIFF ') + 'function ' + name, 'solution/planner.py', 'tests/sound.py')
    bad += not same
import re  # noqa: E402
sim = re.search(r"SIM_C = r'''(.*?)'''", ssrc, re.S).group(1)
same = sim == (TASK / 'tests/gensim.c').read_text()
print(('same ' if same else 'DIFF ') + 'embedded SIM_C', 'solution/planner.py', 'tests/gensim.c')
bad += not same
sys.exit(1 if bad else 0)
