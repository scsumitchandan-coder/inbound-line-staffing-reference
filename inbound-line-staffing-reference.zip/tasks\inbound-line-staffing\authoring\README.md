# authoring/

Nothing here is copied into either image.

## provenance/

- `check_copies.py` confirms the copies the task relies on are the same bytes: the line generator and simulator
  (`environment/_build/` and `tests/`), and the queue engine (`environment/app/engine/` and `tests/engine/`). It
  also confirms the reference planner (`solution/planner.py`) and the verifier's sound methods (`tests/sound.py`)
  share one estimator.
- `survey_draws.py` builds the four role lines of several draws exactly as the verifier does. It scores the band
  methods, two further sound variants and seven rivals (one wrong reading each) by the number of half hours outside
  the accepted range.

Ground truth is generator-derived: `gensim solve` runs the verifier's forward staffing search on the generating model
of each line at its plan date. `gensim.c` is independent of the agent's engine `qplan.c` (separate source, separate
random streams, prefix-truncated days). The two agree on the queue model and differ in the service-level measure,
which is the planted departure. On no-abandonment lines both reproduce Erlang C (`environment/app/engine/checks.csv`).

## evidence/

- `run_battery.py` runs the real `tests/test_outputs.py` inside the verifier image. Only these are patched: the
  planner path, the line seeds (one fixed draw for every candidate) and, for the hanging submission, the time
  limit. Lines are prepared once by the verifier's own `_prepare()` and cached. The output is
  `battery_<draw>.json` (and the console output, `battery_<draw>.txt`); `BATTERY.md` is the table.
- `survey/survey_draws.json` and `survey_draws.txt`: an earlier two-draw survey (four lines, before the bill-cycle and
  closure effects), kept as history; `BATTERY.md` is the evidence for this tree.

The rivals and the extra sound variants are built from `evidence/variants.py`, the reference estimator with
switches; it lives only here, so the shipped reference and the verifier's sound methods stay switchless. The rivals
each carry one wrong reading:

| rival | wrong reading |
|---|---|
| `rv_engine_service_level` | staffs with `qplan.staff()`, which measures answered-in-time over answered calls |
| `rv_strip_repeats` | removes linked repeats and assumes nobody rings again under the new plan |
| `rv_all_attempts_new` | counts every recorded attempt as a new caller and assumes nobody rings again (inert: its error is about the band's size, so it is reported, not claimed) |
| `rv_pooled_handle_time` | ignores the handle-time step; fits all eight weeks |
| `rv_no_trend` | ignores the volume trend; averages the eight weeks |
| `rv_fixed_utc_offset` | converts with the first record's UTC offset, so a clock change in the records is missed |
| `rv_no_speedup` | one handle-time distribution for all answered calls |
| `rv_no_bill_cycle` | ignores the monthly bill cycle: weekday, trend and closures only |
| `rv_no_closure_effect` | ignores closures: the catch-up day counts as an ordinary day and the plan date gets no catch-up |
| `rv_all_return_evenly` | every caller of the closed day returns on the plan date, spread like an ordinary day |

The sound variants differ from the reference in settings a careful planner might choose: handle times from the last
two weeks with the trend always fitted, looser change-point and trend tests, and 600 simulated days.
