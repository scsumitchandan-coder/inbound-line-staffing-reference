# Battery through the real verifier (draw 20261015)

`run_battery.py` inside the verifier image, on this tree. Every candidate is graded on the same six lines (rising,
step, clock, falling-step, bill, holiday). Cells: half hours outside the accepted range on that line (deviation from
the true requirement, min..max), or why no plan was read. Expected: reference and sound variants 1; rivals and
malformed submissions 0. The variant and rival planners are built from `variants.py` (the reference with switches);
`reference` is the shipped `solution/planner.py` itself.

| candidate | reward | rising | step | clock | falling-step | bill | holiday |
|---|---|---|---|---|---|---|---|
| reference | 1 | 0 (-1..+3) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 0 (+0..+4) | 0 (-3..+1) |
| sound_recent_handle_always_trend | 1 | 0 (-1..+4) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+3) | 0 (-3..+1) |
| sound_looser_change_tests | 1 | 0 (-1..+3) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+4) | 0 (-3..+0) |
| sound_more_days | 1 | 0 (-1..+3) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+4) | 0 (-3..+1) |
| rv_engine_service_level | 0 | 5 (-3..+0) | 7 (-3..+0) | 6 (-3..-1) | 16 (-3..-1) | 1 (-2..+1) | 12 (-6..-1) |
| rv_strip_repeats | 0 | 1 (-2..+2) | 7 (-3..+0) | 0 (-2..+0) | 11 (-3..+0) | 6 (-3..+1) | 6 (-4..+0) |
| rv_all_attempts_new | 0 | 0 (-1..+4) | 0 (-1..+1) | 0 (-1..+1) | 1 (-2..+0) | 24 (+2..+15) | 11 (-1..+20) |
| rv_pooled_handle_time | 0 | 0 (-1..+3) | 5 (-2..+0) | 0 (-1..+1) | 6 (-2..+0) | 0 (+0..+4) | 0 (-3..+1) |
| rv_no_trend | 0 | 23 (-8..-1) | 0 (-1..+1) | 0 (-1..+1) | 10 (+0..+4) | 0 (+0..+4) | 0 (-3..+1) |
| rv_fixed_utc_offset | 0 | 15 (-17..+7) | 5 (-7..+3) | 10 (-8..+3) | 11 (-10..+3) | 0 (+0..+4) | 1 (-4..+1) |
| rv_no_speedup | 0 | 2 (-2..+5) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 7 (-1..+6) | 0 (-2..+1) |
| rv_no_bill_cycle | 0 | 1 (+0..+4) | 0 (-1..+1) | 0 (-1..+1) | 14 (+0..+4) | 24 (-13..-2) | 5 (-4..+1) |
| rv_no_closure_effect | 0 | 0 (-1..+3) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 24 (-13..-2) | 17 (-40..-1) |
| rv_all_return_evenly | 0 | 0 (-1..+3) | 0 (-1..+1) | 0 (-1..+1) | 0 (-1..+1) | 0 (+0..+4) | 20 (-21..+19) |
| abuse_missing | 0 | /app/planner.py must be a regular file |  |  |  |  |  |
| abuse_wrong_length | 0 | plan of wrong length | plan of wrong length | plan of wrong length | plan of wrong length | plan of wrong length | plan of wrong length |
| abuse_crash | 0 | planner failed: Traceback (most recent c | planner failed: Traceback (most recent c | planner failed: Traceback (most recent c | planner failed: Traceback (most recent c | planner failed: Traceback (most recent c | planner failed: Traceback (most recent c |
| abuse_constant | 0 | 24 (-16..+44) | 24 (+33..+54) | 26 (+26..+52) | 24 (+26..+53) | 24 (+6..+49) | 22 (+7..+50) |
| abuse_read_secret | 0 | plan of wrong length | plan of wrong length | plan of wrong length | plan of wrong length | plan of wrong length | plan of wrong length |
| abuse_hang | 0 | no plan within 30 s | no plan within 30 s | no plan within 30 s | no plan within 30 s | no plan within 30 s | no plan within 30 s |

Result: PASS. Reference and the three sound variants score 1; the nine claimed rivals and all six malformed
submissions score 0. `rv_all_attempts_new` (every recorded attempt counted as a new caller, nobody ringing again) is
reported but not claimed: its error is about the size of the band on ordinary lines (it is outside here mainly on the
bill and holiday lines, where congestion-driven repeats are many).
